<?php
// Definir ruta base del proyecto
define("BASE_PATH", dirname(__DIR__, 3));

// Cargar controller interno
require_once BASE_PATH . "/src/controllers/login/user.php";
