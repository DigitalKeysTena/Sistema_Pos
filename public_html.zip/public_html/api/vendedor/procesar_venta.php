<?php
// public_html/api/vendedor/procesar_venta.php
define("BASE_PATH", dirname(__DIR__, 3));
require_once BASE_PATH . "/src/controllers/vendedor/procesar_venta.php";
