<?php
// public_html/api/vendedor/registrar_retiro.php
define("BASE_PATH", dirname(__DIR__, 3));
require_once BASE_PATH . "/src/controllers/vendedor/registrar_retiro.php";
