<?php
// public_html/api/vendedor/guardar_cliente.php
define("BASE_PATH", dirname(__DIR__, 3));
require_once BASE_PATH . "/src/controllers/vendedor/guardar_cliente.php";
