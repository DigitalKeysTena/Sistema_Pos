<?php
// public_html/api/vendedor/obtener_retiros.php
define("BASE_PATH", dirname(__DIR__, 3));
require_once BASE_PATH . "/src/controllers/vendedor/obtener_retiros.php";
