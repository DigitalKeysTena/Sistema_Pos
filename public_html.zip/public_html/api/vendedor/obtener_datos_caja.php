<?php
// public_html/api/vendedor/obtener_datos_caja.php
define("BASE_PATH", dirname(__DIR__, 3));
require_once BASE_PATH . "/src/controllers/vendedor/obtener_datos_caja.php";
