<?php
// public_html/api/vendedor/buscar_producto.php
define("BASE_PATH", dirname(__DIR__, 3));
require_once BASE_PATH . "/src/controllers/vendedor/buscar_producto.php";
