<?php
define("BASE_PATH", dirname(__DIR__, 3));
require_once BASE_PATH . "/src/controllers/Inventario/agg_Inventario.php";
