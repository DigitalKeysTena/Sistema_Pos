<?php
define("BASE_PATH", dirname(__DIR__, 3));
require_once BASE_PATH . "/src/controllers/Inventario/buscar_producto_por_codigo.php";
